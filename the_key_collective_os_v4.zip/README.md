# The Key Collective OS v4

Upload the contents of this folder to the root of your GitHub Pages repository.

Included:
- index.html
- key-collective-logo.png
- key-profile.jpg
- apple-touch-icon.png
- manifest.webmanifest

The app stores personal entries locally in the browser. Use Premium Studio > Data Vault to export a backup.
